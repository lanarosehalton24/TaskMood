# TaskMood - AI-Powered Task Management

## Overview

TaskMood is a modern full-stack web application that combines intelligent task management with mood-based productivity insights. The system uses AI to analyze user moods and provide personalized task recommendations, while offering real-time team collaboration features through WebSocket-powered chat functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development patterns
- **Build Tool**: Vite for fast development builds and hot module replacement
- **Routing**: Wouter for lightweight client-side routing without the complexity of React Router
- **State Management**: TanStack Query (React Query) for server state management, caching, and synchronization
- **UI Framework**: Radix UI primitives with shadcn/ui component system for accessible, customizable components
- **Styling**: Tailwind CSS with CSS variables for consistent theming and dark mode support
- **Real-time Communication**: Custom WebSocket hook for live chat and notifications

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules for better tree-shaking and modern syntax
- **API Design**: RESTful endpoints with WebSocket support for real-time features
- **Authentication**: Replit Auth integration using OpenID Connect protocol
- **Session Management**: Express sessions with PostgreSQL storage for scalability
- **Error Handling**: Centralized error middleware with structured error responses

### Data Storage Solutions
- **Primary Database**: PostgreSQL with Neon serverless hosting for scalability
- **ORM**: Drizzle ORM chosen for type safety, performance, and SQL-like syntax
- **Schema Management**: Drizzle Kit for database migrations and schema synchronization
- **Session Store**: PostgreSQL-backed session storage using connect-pg-simple

## Key Components

### Authentication System
- **Provider**: Replit Auth with OpenID Connect for seamless integration
- **Session Security**: HTTP-only cookies with secure flags and CSRF protection
- **User Management**: Role-based access control supporting student, staff, and employee roles
- **Token Handling**: Automatic token refresh and session validation

### Task Management Engine
- **CRUD Operations**: Complete task lifecycle management with validation
- **Priority System**: Three-tier priority levels (high, medium, low) with visual indicators
- **Status Tracking**: Four-state workflow (pending, in-progress, completed, overdue)
- **Smart Categorization**: Automatic categorization with manual override capabilities
- **Due Date Management**: Intelligent deadline tracking with notification system

### AI Integration Layer
- **Mood Analysis**: OpenAI GPT-4o integration for natural language mood interpretation
- **Task Suggestions**: Context-aware task prioritization based on mood and workload
- **Smart Greetings**: Personalized AI-generated greetings based on user state
- **Voice Input**: Speech-to-text integration for hands-free task creation and messaging

### Real-time Communication
- **WebSocket Server**: Native WebSocket implementation with user authentication
- **Live Chat**: Real-time messaging with typing indicators and online status
- **Push Notifications**: Instant updates for task assignments and deadlines
- **Connection Management**: Automatic reconnection with exponential backoff

## Data Flow

### Authentication Flow
1. User accesses protected route
2. Middleware checks for valid session
3. If unauthenticated, redirects to Replit OAuth
4. On successful auth, creates/updates user record
5. Establishes session with PostgreSQL storage

### Task Management Flow
1. User creates task via form or voice input
2. Client validates input using Zod schemas
3. Server processes and stores in PostgreSQL
4. Real-time notifications sent via WebSocket
5. Analytics updated for dashboard metrics

### AI Mood Analysis Flow
1. User inputs mood via interface or chat
2. Text sent to OpenAI GPT-4o for analysis
3. AI returns structured mood data and suggestions
4. Results stored for trend analysis
5. Task recommendations updated based on mood

### Real-time Communication Flow
1. Client establishes WebSocket connection
2. Server authenticates and stores connection
3. Messages broadcast to relevant users
4. Offline messages queued in database
5. Connection state synced across devices

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection pooling
- **drizzle-orm**: Type-safe database operations and query building
- **openai**: Official OpenAI API client for GPT-4o integration
- **openid-client**: OpenID Connect client for Replit Auth
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/react-***: Accessible UI primitive components

### Development Tools
- **vite**: Fast development server and build tool
- **typescript**: Type checking and enhanced developer experience
- **tailwindcss**: Utility-first CSS framework
- **drizzle-kit**: Database schema management and migrations

### Authentication Services
- **Replit Auth**: OAuth provider for user authentication
- **connect-pg-simple**: PostgreSQL session store for Express

## Deployment Strategy

### Production Build
- Frontend builds to static files served by Express
- Backend compiles to single JavaScript bundle
- Environment variables required for database and API keys
- Static assets served with proper caching headers

### Database Setup
- PostgreSQL schema managed through Drizzle migrations
- Session table automatically created by connect-pg-simple
- Database URL required via environment variable
- Connection pooling handled by Neon serverless

### Environment Configuration
Required environment variables:
- `DATABASE_URL`: PostgreSQL connection string
- `OPENAI_API_KEY`: OpenAI API access token
- `REPL_ID`: Replit application identifier
- `REPLIT_DOMAINS`: Allowed domains for CORS
- `SESSION_SECRET`: Session encryption key
- `ISSUER_URL`: OpenID Connect issuer URL (defaults to Replit)

### Scaling Considerations
- WebSocket connections handled in-memory (consider Redis for multi-instance)
- Database queries optimized with proper indexing
- Static assets can be served via CDN
- Session store scales with PostgreSQL connection limits